package com.nure.Course.Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaloonMsApplication {
	public static void main(String[] args) {
		SpringApplication.run(SaloonMsApplication.class, args);
	}

}
